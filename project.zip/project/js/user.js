    var tempKeywordSaving = "savings";
    var tempKeywordChecking = "checking";
    var tempKeywordOther = "other"

    var Balance = 1000;
    var checkingBalance = 0;
    var savingBalance = Balance;
    var finalBalance = 0;
    var currentBalance = savingBalance+checkingBalance;

    var otherAccoutBalance = 0;

    var currentBalanceInput = document.getElementById('currentBalance');
    var amountInput = document.getElementById('amount');
    var finalBalanceInput = document.getElementById('finalBalance');

    var labelAccountNumber = document.getElementById('labelmessage');
    var accountNumberInput = document.getElementById('otheraccount');

    var labelMoneyTransferMessage = document.getElementById('moneyTransferMessage');
    var otherAccountNumber = document.getElementById('otheraccount');
    
    setCurrentBalance();

    document.getElementById("fromselect").style.backgroundColor = "yellow";
    document.getElementById("toselect").style.backgroundColor = "yellow";

    document.getElementById("currentBalance").style.backgroundColor = "red";
    document.getElementById("currentBalance").style.fontWeight = "bold";
    document.getElementById("currentBalance").style.fontSize = "30px";
    document.getElementById("finalBalance").style.backgroundColor = "red";

    

    var buttonAdd = document.getElementById("calculate")
   buttonAdd.addEventListener("click", methodTransfer);
    function methodTransfer() {

        var fromAccount = document.getElementById("fromselect").value;
        var toAccount = document.getElementById("toselect").value;
        var tempAmount = parseInt(amountInput.value); 

    if ((fromAccount.match("saving")) && (toAccount.match("checking"))) {

        //amountInput.value = "";

        labelAccountNumber.style.display = "none";
        accountNumberInput.style.display = "none";

        if (savingBalance == 0) {
            alert('Balance Is Zero\nFirst Add Money Into Your Saving Account....')
        } else if (savingBalance < tempAmount) {
            alert('InSufficient Balance\nPlease Enter Amount Again!!');
        } else {
        console.log('s->c');
        console.log("From : "+fromAccount)
        console.log("To : "+toAccount)
        checkingBalance+=tempAmount;
        savingBalance-=tempAmount;

        console.log("Checking : "+checkingBalance);
        console.log("Saving : "+savingBalance);
        
        //currentBalance-=tempAmount;

        setCurrentBalance();
        }
    } else if ((fromAccount.match("checking")) && (toAccount.match("saving"))) {

        //amountInput.value = "";

        labelAccountNumber.style.display = "none";
        accountNumberInput.style.display = "none";

        console.log('c->s')
        if (checkingBalance == 0) {
            alert('Balance Is Zero\nFirst Add Money Into Your Checking Account....')
        } else if (checkingBalance < tempAmount) {
            alert('InSufficient Balance\nPlease Enter Amount Again!!');
        }
        else {
        console.log("From : "+fromAccount)
        console.log("To : "+toAccount)
        savingBalance+=tempAmount;
        checkingBalance-=tempAmount;

        //currentBalance-=tempAmount;

        console.log("Checking : "+checkingBalance);
        console.log("Saving : "+savingBalance);
        setCurrentBalance();
        }
    } else if ((fromAccount.match("saving")) && (toAccount.match("other"))) {

        //amountInput.value = "";

        //labelAccountNumber.style.display = "block";
        //accountNumberInput.style.display = "block";

        var tempAccount = otheraccount.value;
        

        console.log('s->o')
        if (savingBalance == 0) {
            alert('Balance Is Zero\nFirst Add Money Into Your Saving Account....')
        } else if (savingBalance < tempAmount) {
            alert('InSufficient Balance\nPlease Enter Amount Again!!');
        } else if (tempAccount.length != 10) {
            alert('Account No. Must be of 10 digits....')
        }
        else {
        console.log("From : "+fromAccount)
        console.log("To : "+toAccount)
        otherAccoutBalance+=tempAmount;
        savingBalance-=tempAmount;

        currentBalance-=tempAmount;

        console.log("Saving : "+savingBalance);
        console.log("Other : "+otherAccoutBalance);
        setCurrentBalance();

        var subStringAccount = tempAccount.substr(0,5)+"*****";
    
        
        document.getElementById('moneyTransferMessage').innerText = 'Money Transfered to Account No : '+subStringAccount;
        labelMoneyTransferMessage.style.display = "block";
        }
    } else if ((fromAccount.match("checking")) && (toAccount.match("other"))) {

        //amountInput.value = "";

        

        //labelAccountNumber.style.display = "block";
        //accountNumberInput.style.display = "block";

        var tempAccount = otheraccount.value;

        console.log('c->0')
        if (checkingBalance == 0) {
            alert('Balance Is Zero\nFirst Add Money Into Your Checking Account....')
        } else if (checkingBalance < tempAmount) {
            alert('InSufficient Balance\nPlease Enter Amount Again!!');
        }
        else {
        console.log("From : "+fromAccount)
        console.log("To : "+toAccount)
        otherAccoutBalance+=tempAmount;
        checkingBalance-=tempAmount;

        currentBalance-=tempAmount;

        console.log("Checking : "+checkingBalance);
        console.log("Other : "+otherAccoutBalance);
        setCurrentBalance();

        var subStringAccount = tempAccount.substr(0,5)+"****";

        document.getElementById('moneyTransferMessage').innerText = 'Money Transfered to Account No : '+subStringAccount;
        labelMoneyTransferMessage.style.display = "block";
        }
    }
}

function setCurrentBalance() {
    currentBalanceInput.value = currentBalance;
}

function onOptionChange() {
    var x = document.getElementById("toselect").value;

    if (x.match("other")) {
        labelAccountNumber.style.display = "block";
        accountNumberInput.style.display = "block";
    } else {
        otherAccountNumber.value = "";
        labelAccountNumber.style.display = "none";
        accountNumberInput.style.display = "none";
    }
}