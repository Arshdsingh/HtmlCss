<html>
<head>
<title>User</title>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/bootstrap-theme.css" rel="stylesheet">

<style>
    .other,.accountLabel,.moneytransfer {
        display : none;
    }
</style>

</head>
<body class="container">
    <h3>Welcome : <?php echo $_POST["user_name"] ?></h3>
    <h2 id="wUser">Transfer Funds</h2>
    From :  <br/>
    <select id="fromselect" class="form-control" >
        <option value="saving">Savings</option>
        <option value="checking">Checking</option>
    </select>
    <br/>
    To : <br/>
    <select id="toselect" class="form-control" onchange="onOptionChange()"  >
            <option  value="checking">Checking</option>
            <option  value="saving">Savings</option>
            <option value="other">Other</option>
    </select>
    <br/>
    <label id="labelmessage" class = "accountLabel">Account Number :</label><input  id="otheraccount" type="number" class="form-control other" >
    Current Balance : <br/>
    <!--<label class="form-control" id="labelbalance" for=""> </label>-->
   <input  id="currentBalance" type="number" class="form-control" readonly >
    <br/>
    Amount : <br/>
    <input  id="amount" type="number" class="form-control" >
    <br/>
    Final Balance : <br/>
    <input  id="finalBalance" type="number" class="form-control">
    <br/>
    <input id="calculate" type="submit" value="Submit" class="btn-success">
    <span id="moneyTransferMessage" class="text-danger moneytransfer">Money Transfered to ********</span>
    <script src="js/user.js">
 </script>
</body>
</html>